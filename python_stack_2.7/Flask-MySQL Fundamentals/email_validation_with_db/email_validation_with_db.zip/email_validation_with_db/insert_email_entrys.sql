INSERT INTO email_address_book_db.email_addresses (email_addresses.email_address, email_addresses.created_at, email_addresses.updated_at)
	VALUES ("tandd2015@outlook.com", NOW(), NOW());
    
INSERT INTO email_address_book_db.email_addresses (email_addresses.email_address, email_addresses.created_at, email_addresses.updated_at)
	VALUES ("unchained_26_1988@outlook.com", NOW(), NOW());