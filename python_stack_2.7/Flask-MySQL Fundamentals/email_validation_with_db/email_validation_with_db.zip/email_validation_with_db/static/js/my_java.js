$(document).ready(function(){
    $(document).on('click', 'button', function(){
    });
});