INSERT INTO full_friendsdb.friends (friends.first_name, friends.last_name, friends.occupation, friends.created_at, friends.updated_at) 
	VALUES ("Beth", "Sanchez", "Horse surgeon", NOW(), NOW());

INSERT INTO full_friendsdb.friends (friends.first_name, friends.last_name, friends.occupation, friends.created_at, friends.updated_at) 
	VALUES ("Zaphod", "Beeblebrox", "President of the Galaxy",NOW(), NOW());

INSERT INTO full_friendsdb.friends (friends.first_name, friends.last_name, friends.occupation, friends.created_at, friends.updated_at)
	VALUES ("Ash", "Ketchum", "Trainer", NOW(), NOW());
