def findReplace():
    words = "It's thanksgiving day. It's my birthday,too!"
    print words.find("day")
    newWords = words.replace("day", "month")
    print newWords
findReplace()
