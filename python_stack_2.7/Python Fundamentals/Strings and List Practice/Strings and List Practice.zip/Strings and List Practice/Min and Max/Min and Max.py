def minMax(x):
    print x
    print min(x)
    print max(x)
minMax([2,54,-2,7,12,98])