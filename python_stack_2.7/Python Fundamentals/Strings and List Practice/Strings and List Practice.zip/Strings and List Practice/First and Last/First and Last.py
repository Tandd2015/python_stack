def firstLast(x):
    print x[0], x[len(x) - 1]
firstLast(["hello",2,54,-2,7,12,98,"world"])
