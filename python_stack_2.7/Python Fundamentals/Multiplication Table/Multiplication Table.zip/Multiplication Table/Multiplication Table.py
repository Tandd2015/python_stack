def multiplicity(x, y): #beginning of function where x and y is passed into for multiplication table
    print "My Mutlipication Table:"
    for vertical in xrange(0, x + 1): # a for loop to run through the range of x and to setup vertical variable
        if vertical is 0: # conditional testing and replacing any mutiplications of zero for the vertical variable
            vertical = vertical + 1
        for horizontal in xrange(0, y + 1): #a nested foor loop to get the range of y and to setup the horizontal variable
            if horizontal is 0: # conditional testing and replacing any mutiplications of zero for the vertical variable
                horizontal = horizontal + 1
            print vertical * horizontal, "\t",
        print # printing the multiplication table in a horizontal tab
        # end of function 
multiplicity(12, 12) # calling function and passing parameters into the variables of x and y.
