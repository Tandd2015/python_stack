def fooBar(): # beginning of the function
    for idx in range(1, 100001): # beginning of the foor loop that will cycle through all of the numbers
        prime = True # variable for prime
        perfect_4 = False # variable for perfect square
        for check in range(2, idx + 1): # nested foor loop that will cycle a check for each idx number
            if idx % check == 0 and check != idx: # a conditional  that will check to see if the number is prime
                prime = False # changes the value of the variable 
            if idx // check == check: # a conditional that will check to see if the number is a perfect square
                perfect_4 = True # changes the value of the variable
        if prime is True: # a conditional that will print for prime numbers
            print 'Foo'
        elif perfect_4 is True: # a conditional that will print for perfect square numbers
            print 'Bar'
        else: # a conditional that will print for neither perfect square or prime numbers
            print 'FooBar'
fooBar() # end of function