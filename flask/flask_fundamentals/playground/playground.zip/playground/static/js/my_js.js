$(document).ready(function(){
    $(".box").css("background-color", $('.box').attr('alt'));
});