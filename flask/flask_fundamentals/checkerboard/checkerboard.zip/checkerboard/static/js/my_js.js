$(document).ready(function(){
    $(".check_2").css("background-color", $('.check_1').attr('alt1'))
    $(".check_1").css("background-color", $('.check_2').attr('alt2'))
});