from django.apps import AppConfig


class ShowMakerConfig(AppConfig):
    name = 'show_maker'
