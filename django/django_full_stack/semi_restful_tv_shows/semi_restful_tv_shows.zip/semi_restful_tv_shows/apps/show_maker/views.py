from django.shortcuts import render, redirect
from .models import *
import datetime

# Create your views here.
def index1(request):
    return render(request, 'show_maker/index.html')

def new_show_add(request):
    count= 0
    if len(request.POST['title_input']) <= 0:
        count+=1
    
    if len(request.POST['network_input']) <= 0:
        count+=1
    
    if len(request.POST['release_date_input']) <= 0:
        count+=1
    
    if len(request.POST['description_input']) <= 0:
        count+=1
    
    if count == 0:
        new_show_added= Show.objects.create(title=request.POST['title_input'],network=request.POST['network_input'],descript=request.POST['description_input'], rel_date=request.POST['release_date_input'])
        return redirect(f'/shows/{new_show_added.id}')
    return redirect('/shows')

def new_show_index(request, the_show_id):
    showing= Show.objects.get(id=the_show_id)
    context= {
        'watching': showing,
    }
    return render(request, 'show_maker/new_show_index.html', context)

def all_show_index(request):
    all_shows = Show.objects.all()
    context = {
        'showzzz': all_shows,
    }
    return render(request, 'show_maker/all_show_index.html', context)

def edit_show_index(request, the_edit_id):
    edit_shows= Show.objects.get(id=the_edit_id)
    context= {
        'editzzz': edit_shows,
    }
    return render(request, 'show_maker/edit_show_index.html', context)

def update_show(request, the_update_id):
    count= 0
    if len(request.POST['edit_title_input']) <= 0:
        count+=1
    
    if len(request.POST['edit_network_input']) <= 0:
        count+=1
    
    if len(request.POST['edit_release_date_input']) <= 0:
        count+=1
    
    if len(request.POST['edit_description_input']) <= 0:
        count+=1
    print(request.POST)
    if count == 0:
        updating= Show.objects.get(id=the_update_id)
        updating.title= request.POST['edit_title_input']
        updating.network= request.POST['edit_network_input']
        updating.rel_date= request.POST['edit_release_date_input']
        updating.descript= request.POST['edit_description_input']
        updating.save()
        return redirect(f'/shows/{the_update_id}')
    return redirect(f'/shows/{the_update_id}/edit')

def destroy_show(request, the_destroy_id):
    destroyed= Show.objects.get(id=the_destroy_id)
    destroyed.delete()
    return redirect('/shows')