from django.db import models

import datetime

# Create your models here.
class Show(models.Model):
    title = models.CharField(max_length=255)
    network = models.CharField(max_length=255)
    descript = models.TextField()
    rel_date = models.DateTimeField(auto_now_add=False, default=datetime.datetime.now().strftime("%m/%d/%Y"))
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)