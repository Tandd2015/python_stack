# print python 3
print("Python 3's print is a function!")
# print python 2.7print "Python 2.7's print is a statement!"
print "Python 2.7's print is a statement!"

